#ifndef YES_OR_NO_H_INCLUDED
#define YES_OR_NO_H_INCLUDED

//This file contains a simple choice function.
bool choice();

#endif // YES_OR_NO_H_INCLUDED
